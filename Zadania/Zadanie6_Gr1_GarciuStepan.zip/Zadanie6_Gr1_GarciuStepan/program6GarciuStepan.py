import PySimpleGUI as sg
import numpy as np
import copy
import cv2
import random
from matplotlib import pyplot as plt

"""
Definicja wymaganych funkcji
"""
def resize_image(image, height, width):
    # Funkcja do skalowania obrazu
    newSize = (height, width)
    # zmiana rozmiarów obrazu z pomocą opencv
    source_image_resized = cv2.resize(image, newSize, interpolation = cv2.INTER_AREA)
    # konwersja obrazu do formatu .png
    source_image_resized = cv2.imencode(".png", source_image_resized)[1].tobytes()
    return source_image_resized

def noise_generator(image_to_noise, thres):
    for i in range(image_to_noise.shape[0]):
        for j in range(image_to_noise.shape[1]):
            rdn = random.random()
            if rdn > thres:
                image_to_noise[i][j] = 255
    return image_to_noise

left_column = [
    [sg.Text("Garciu Stepan")],
    [sg.Text("Poziom szumu"), sg.In(size=(5,1), default_text="0.95", key="-NOISE_LEVEL-")],
    [sg.Text("Generuj sztuczny obraz")],
    [sg.Button('Generuj 1', key="-CREATE_IMG1-")],
    [sg.Text("Generuj sztuczny obraz")],
    [sg.Button('Generuj 2', key="-CREATE_IMG2-")],
    [sg.Image(key="-IMAGE-")]
]

center_column = [
    [sg.Text("Filtracja z FFT2D")],
    [sg.Text("Rozmiar okna filtra"), sg.In(size=(5, 1), default_text="5", key="-FILTER_SIZE-")],
    [sg.Button('Filtr dolnoprzepustowy', key="-FILTER_LOW-")],
    [sg.Button('Filtr gornoprzepustowy', key="-FILTER_HIGH-")]
]

right_column = [
    [sg.Text("Obraz amplitudy po FFT2D"), sg.Text("                        Obraz okna filtra")],
    [sg.Image(key="-IMAGE_AMPLITUDE-"), sg.Image(key="-IMAGE_FILTER-")],
    [sg.Text("Obraz wynikowy po filtracji")],
    [sg.Image(key="-IMAGE_DIST-")]
]



layout = [
    [
        sg.Column(left_column),
        sg.VSeparator(),
        sg.Column(center_column),
        sg.VSeparator(),
        sg.Column(right_column)
    ]
]

# Utworzenie okna z przygotowanym rozkładem trzykolumnowym

window = sg.Window("Program6GarciuStepan", layout, resizable=True,
                   size=(1300, 600), finalize=True)

source_image = None # Zmienna reprezentująca obraz do analizy
image_noisy = None # Zmienna reprezentująca obraz po zaszumieniu

# Utworzenie pętli zdarzeń okna aplikacji
while True:
    event, values = window.read()
    # Zakończenie działania aplikacji i zamknięcie okna
    # gdy wyjście z aplikacji
    if event == "Exit" or event == sg.WIN_CLOSED:
        break
    # Obsługa operacji na obrazie
    # Wczytanie obrazu i dodanie zakłocen
    if event == '-CREATE_IMG1-': # Reakcja na przycisk Generowania obrazu 1
        source_image = cv2.imread("fourier_1_kwadrat_128.png", cv2.IMREAD_GRAYSCALE)
        noise_level = float(values["-NOISE_LEVEL-"]) # Odczyt wartości poziomu szumu
        # Zaszumienie obrazu
        image_noisy = noise_generator(source_image, noise_level)
        image_resized_to_show=resize_image(image_noisy, 250, 250)
        window['-IMAGE-'].update(data=image_resized_to_show)
        window['-FILTER_SIZE-'].update('5')

    if event == '-CREATE_IMG2-': # Reakcja na przycisk Generowania obrazu 2
        source_image = cv2.imread("fourier_2_lena_128.png", cv2.IMREAD_GRAYSCALE)
        noise_level = float(values["-NOISE_LEVEL-"]) # Odczyt wartości poziomu szumu
        # Zaszumienie obrazu
        image_noisy = noise_generator(source_image, noise_level)
        image_resized_to_show=resize_image(image_noisy, 250, 250)
        window['-IMAGE-'].update(data=image_resized_to_show)
        window['-FILTER_SIZE-'].update('25')

    if event == '-FILTER_LOW-': # Reakcja na przycisk Filtr dolnoprzepustowy
        # Filtracja dolnoprzepustowa z użyciem FFT 2D
        # Transformacja Fouriera 2D dla obrazu zaszumionego
        dft = cv2.dft(np.float32(image_noisy), flags = cv2.DFT_COMPLEX_OUTPUT)
        dft_shift = np.fft.fftshift(dft) # Przesunięcie częstotliwości zerowej do środka widma
        # Skalowanie wartości w celu prezentacji
        magnitude = 20*np.log(cv2.magnitude(dft_shift[:,:,0], dft_shift[:,:,1]))
        # Obraz amplitudy po FFT 2D
        image_resized_to_show = resize_image(magnitude, 250, 250)
        window['-IMAGE_AMPLITUDE-'].update(data=image_resized_to_show)
        # Przygotowanie obrazu maski filtra dolnoprzepustowego o rozmiarze obrazu
        rows, cols = image_noisy.shape
        crop_row, crop_col = (int(rows/2), int(cols/2))
        mask_low = np.zeros((rows, cols, 2), np.uint8) # Macierz 0 - zer
        # Odczyt wielkosci okna filtra (do wycinania zakresu częstotliwości)
        w_size = int(values["-FILTER_SIZE-"])
        mask_low[crop_row-w_size:crop_row+w_size, crop_col-w_size:crop_col+w_size] = 1
        # Zastosowanie filtra (mnożenie obrazu po transformacie i maski filtra LOW)
        magnitude_low = dft_shift * mask_low

        magnitude_low = np.fft.ifftshift(magnitude_low) # Przesunięcie częstotliwości zerowej ze środka widma
        img_back_low = cv2.idft(magnitude_low) # Odwrotna transformata Fouriera
        magnitude_back_low = cv2.magnitude(img_back_low[:,:,0], img_back_low[:,:,1]) # Obraz po filtracji

        image_normalized = cv2.normalize(mask_low[:, :, 0], None, 0, 255, cv2.NORM_MINMAX)
        image_resized_to_show=resize_image(image_normalized, 250, 250)
        window['-IMAGE_FILTER-'].update(data=image_resized_to_show)

        image_normalized = cv2.normalize(magnitude_back_low, None, 0, 255, cv2.NORM_MINMAX)
        image_resized_to_show=resize_image(image_normalized, 250, 250)
        window['-IMAGE_DIST-'].update(data=image_resized_to_show)

    if event == '-FILTER_HIGH-': # Reakcja na przycisk Filtr górnoprzepustowy
        # Filtracja górnoprzepustowa z użyciem FFT 2D

        # Transformacja Fouriera 2D dla obrazu zaszumionego
        dft = cv2.dft(np.float32(image_noisy), flags = cv2.DFT_COMPLEX_OUTPUT)
        dft_shift = np.fft.fftshift(dft) # Przesunięcie częstotliwości zerowej do środka widma
        # Skalowanie wartości w celu prezentacji
        magnitude = 20*np.log(cv2.magnitude(dft_shift[:, :, 0], dft_shift[:,:,1]))
        # Obraz amplitudy po FFT 2D
        image_resized_to_show = resize_image(magnitude, 250, 250)
        window['-IMAGE_AMPLITUDE-'].update(data=image_resized_to_show)
        # Przygotowanie obrazu maski filtra dolnoprzepustowego o rozmiarze obrazu
        rows, cols = image_noisy.shape
        crop_row, crop_col = (int(rows/2), int(cols/2))
        # Odczyt wielkości okna filtra (do wycinania zakresu częstotliwości)
        w_size = int(values["-FILTER_SIZE-"])
        mask_high = np.ones((rows, cols, 2), np.uint8) # Macierz 1 - jedynek
        mask_high[crop_row-w_size:crop_row+w_size, crop_col-w_size:crop_col+w_size] = 0
        # Zastosowanie filtra (mnożenie obrazu po transformacie i maski filtra HIGH)
        magnitude_high = dft_shift * mask_high

        magnitude_high = np.fft.ifftshift(magnitude_high) # Przesunięcie częstotliwości zerowej ze środka widma
        img_back_high = cv2.idft(magnitude_high) # Odwrotna transformacja Fouriera
        magnitude_back_high = cv2.magnitude(img_back_high[:, :, 0], img_back_high[:, :, 1]) # Obraz po filtracji

        
        image_normalized = cv2.normalize(mask_high[:, :, 0], None, 0, 255, cv2.NORM_MINMAX)
        image_resized_to_show = resize_image(image_normalized, 250, 250)
        window['-IMAGE_FILTER-'].update(data=image_resized_to_show)

        image_normalized = cv2.normalize(magnitude_back_high, None, 0, 255, cv2.NORM_MINMAX)
        image_resized_to_show = resize_image(image_normalized, 250, 250)
        window['-IMAGE_DIST-'].update(data=image_resized_to_show)
        
        

        

        
    



































    












