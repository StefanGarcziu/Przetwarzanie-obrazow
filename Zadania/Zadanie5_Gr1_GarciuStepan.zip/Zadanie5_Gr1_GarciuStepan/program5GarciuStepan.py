import PySimpleGUI as sg
import PIL.Image
import numpy as np
import io
import cv2

"""
Definicja wymaganych funkcji
"""
def resize_image(image, height, width):
    # Funkcja do skalowania obrazu
    newSize = (height, width)
    # zmiana rozmiarów obrazu z pomocą opencv
    source_image_resized = cv2.resize(image, newSize, interpolation = cv2.INTER_AREA)
    # konwersja obrazu do formatu .png
    source_image_resized = cv2.imencode(".png", source_image_resized)[1].tobytes()

    return source_image_resized

left_column = [
    [sg.Text("Garciu Stepan"), sg.Button('Obraz', key="-OBRAZ-")],
    [sg.Image(key="-IMAGE-")]
]

center_column = [
    [sg.Text("Operacje")],
    
    [sg.Text("Erozja")],    
    [sg.Text("Rozmiar SE")],    
    [sg.Button('3x3', key="-ERO3x3-"), sg.Button('5x5', key="-ERO5x5-"), sg.Button('7x7', key="-ERO7x7-")],

    [sg.Text("Dylatacja")],    
    [sg.Text("Rozmiar SE")],    
    [sg.Button('3x3', key="-DYL3x3-"), sg.Button('5x5', key="-DYL5x5-"), sg.Button('7x7', key="-DYL7x7-")],

    [sg.Text("Otwarcie")],    
    [sg.Text("Rozmiar SE")],    
    [sg.Button('3x3', key="-OPE3x3-"), sg.Button('5x5', key="-OPE5x5-"), sg.Button('7x7', key="-OPE7x7-")],

    [sg.Text("Zamknięcie")],    
    [sg.Text("Rozmiar SE")],    
    [sg.Button('3x3', key="-CLO3x3-"), sg.Button('5x5', key="-CLO5x5-"), sg.Button('7x7', key="-CLO7x7-")],

    [sg.Text("Gradient Morfolog.")],    
    [sg.Text("Rozmiar SE")],    
    [sg.Button('3x3', key="-GRA3x3-"), sg.Button('5x5', key="-GRA5x5-"), sg.Button('7x7', key="-GRA7x7-")],
]

right_column = [
    [sg.Text("Obraz wynikowy")],
    [sg.Image(key="-IMAGEDIST-")]
]

layout = [
    [
        sg.Column(left_column),
        sg.VSeparator(),
        sg.Column(center_column),
        sg.VSeparator(),
        sg.Column(right_column)
    ]
]

# Utworzenie okna z przygotowanym rozkładem trzykolumnowym

window = sg.Window("Program5GarciuStepan", layout, resizable=True,
                   size=(800, 600), finalize=True)

source_image = None # Zmienna reprezentująca obraz do analizy

# Utworzenie pętli zdarzeń okna aplikacji
while True:
    event, values = window.read()
    # Zakończenie działania aplikacji i zamknięcie okna
    # gdy wyjście z aplikacji
    if event == sg.WIN_CLOSED:
        break
    if event == "-OBRAZ-":
        # Wczytanie pliku za pomocą opencv i zapisanie w zmiennej source_image
        full_file_name="image2Morf.png"
        #full_file_name="imageKwadrat.png"
        source_image = cv2.imread(full_file_name)
        # skalowanie obrazu za pomocą funkcji resize_image(zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(source_image, 250, 250)
        window['-IMAGE-'].update(data=source_image_resized_to_show)

    if event == "-ERO3x3-":
        # przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 3x3
        se3x3 = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
        #operacja erozji elementem strukturalnym SE
        eroded_image = cv2.erode(source_image, se3x3, iterations=1)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(eroded_image, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)
    if event == "-ERO5x5-":
        # przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 5x5
        se5x5 = cv2.getStructuringElement(cv2.MORPH_RECT, (5,5))
        #operacja erozji elementem strukturalnym SE
        eroded_image = cv2.erode(source_image, se5x5, iterations=1)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(eroded_image, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)
    if event == "-ERO7x7-":
        # przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 7x7
        se7x7 = cv2.getStructuringElement(cv2.MORPH_RECT, (7,7))
        #operacja erozji elementem strukturalnym SE
        eroded_image = cv2.erode(source_image, se7x7, iterations=1)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(eroded_image, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)


    if event == "-DYL3x3-":
        # przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 3x3
        se3x3 = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
        #operacja dylatacji elementem strukturalnym SE
        eroded_image = cv2.dilate(source_image, se3x3, iterations=1)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(eroded_image, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)
    if event == "-DYL5x5-":
        # przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 5x5
        se5x5 = cv2.getStructuringElement(cv2.MORPH_RECT, (5,5))
        #operacja dylatacji elementem strukturalnym SE
        eroded_image = cv2.dilate(source_image, se5x5, iterations=1)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(eroded_image, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)
    if event == "-DYL7x7-":
        # przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 7x7
        se7x7 = cv2.getStructuringElement(cv2.MORPH_RECT, (7,7))
        #operacja dylatacji elementem strukturalnym SE
        eroded_image = cv2.dilate(source_image, se7x7, iterations=1)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(eroded_image, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)


    if event == "-OPE3x3-":
        # przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 3x3
        se3x3 = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
        #operacja otwarcia elementem strukturalnym SE
        opened_image = cv2.morphologyEx(source_image, cv2.MORPH_OPEN, se3x3)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(opened_image, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)
    if event == "-OPE5x5-":
        # przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 5x5
        se5x5 = cv2.getStructuringElement(cv2.MORPH_RECT, (5,5))
        #operacja otwarcia elementem strukturalnym SE
        opened_image = cv2.morphologyEx(source_image, cv2.MORPH_OPEN, se5x5)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(opened_image, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)
    if event == "-OPE7x7-":
        # przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 7x7
        se7x7 = cv2.getStructuringElement(cv2.MORPH_RECT, (7,7))
        #operacja otwarcia elementem strukturalnym SE
        opened_image = cv2.morphologyEx(source_image, cv2.MORPH_OPEN, se7x7)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(opened_image, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)



    if event == "-CLO3x3-":
        # przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 3x3
        se3x3 = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
        #operacja zamknięcia elementem strukturalnym SE
        closed_image = cv2.morphologyEx(source_image, cv2.MORPH_CLOSE, se3x3)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(closed_image, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)
    if event == "-CLO5x5-":
        # przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 5x5
        se5x5 = cv2.getStructuringElement(cv2.MORPH_RECT, (5,5))
        #operacja zamknięcia elementem strukturalnym SE
        closed_image = cv2.morphologyEx(source_image, cv2.MORPH_CLOSE, se5x5)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(closed_image, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)
    if event == "-CLO7x7-":
        # przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 7x7
        se7x7 = cv2.getStructuringElement(cv2.MORPH_RECT, (7,7))
        #operacja zamknięcia elementem strukturalnym SE
        closed_image = cv2.morphologyEx(source_image, cv2.MORPH_CLOSE, se7x7)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(closed_image, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)



    if event == "-GRA3x3-":
        # przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 3x3
        se3x3 = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
        #gradient morfologiczny elementem strukturalnym SE
        morph_gradient = cv2.morphologyEx(source_image, cv2.MORPH_GRADIENT, se3x3)
        source_image_resized_to_show=resize_image(morph_gradient, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)
    if event == "-GRA5x5-":
        # przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 5x5
        se5x5 = cv2.getStructuringElement(cv2.MORPH_RECT, (5,5))
        #gradient morfologiczny elementem strukturalnym SE
        morph_gradient = cv2.morphologyEx(source_image, cv2.MORPH_GRADIENT, se5x5)
        source_image_resized_to_show=resize_image(morph_gradient, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)
    if event == "-GRA7x7-":
        # przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 7x7
        se7x7 = cv2.getStructuringElement(cv2.MORPH_RECT, (7,7))
        #gradient morfologiczny elementem strukturalnym SE
        morph_gradient = cv2.morphologyEx(source_image, cv2.MORPH_GRADIENT, se7x7)
        source_image_resized_to_show=resize_image(morph_gradient, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)


window.close()






































