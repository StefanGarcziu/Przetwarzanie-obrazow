import PySimpleGUI as sg
import PIL.Image
import numpy as np
import io
import cv2


"""
Definicja wymaganych funkcji
"""
def resize_image(image, height, width):
    # Funkcja do skalowania obrazu
    newSize = (height, width)
    # zmiana rozmiarów obrazu z pomocą opencv
    source_image_resized = cv2.resize(image, newSize, interpolation = cv2.INTER_AREA)
    # konwersja obrazu do formatu .png
    source_image_resized = cv2.imencode(".png", source_image_resized)[1].tobytes()

    return source_image_resized


left_column = [
    [sg.Text("Garciu Stepan"), sg.Button('Obraz', key="-OBRAZ-")],
    [sg.Image(key="-IMAGE-")]
]

center_column = [
    [sg.Text("Operacje")],
    [sg.Text("Filtr uśredniający")],
    [sg.Text("Rozmiar maski konwolucji filtra")],    
    [sg.Button('3x3', key="-AVG3x3-"), sg.Button('5x5', key="-AVG5x5-"), sg.Button('7x7', key="-AVG7x7-")],
    [sg.Text("Filtr medianowy")],
    [sg.Text("Rozmiar maski konwolucji filtra")],    
    [sg.Button('3x3', key="-MED3x3-"), sg.Button('5x5', key="-MED5x5-"), sg.Button('7x7', key="-MED7x7-")],
    [sg.Text("Detekcja krawędzi SOBEL")],    
    [sg.Button('Sobel -', key="-SOBEL1-"), sg.Button('Sobel |', key="-SOBEL2-"), sg.Button('Sobel -|', key="-SOBEL3-")],
    [sg.Text("Detekcja krawędzi CANNY")],    
    [sg.Button('Canny', key="-CANNY-")]
]

right_column = [
    [sg.Text("Obraz wynikowy")],
    [sg.Image(key="-IMAGEDIST-")]
]


layout = [
    [
        sg.Column(left_column),
        sg.VSeparator(),
        sg.Column(center_column),
        sg.VSeparator(),
        sg.Column(right_column)
    ]
]

# Utworzenie okna z przygotowanym rozkładem trzykolumnowym

window = sg.Window("Program4GarciuStepan", layout, resizable=True,
                   size=(800, 600), finalize=True)

source_image = None # Zmienna reprezentująca obraz do analizy
# Utworzenie pętli zdarzeń okna aplikacji
while True:
    event, values = window.read()
    # Zakończenie działania aplikacji i zamknięcie okna
    # gdy wyjście z aplikacji
    if event == sg.WIN_CLOSED:
        break
    if event == "-OBRAZ-":
        # Wczytanie pliku za pomocą opencv i zapisanie w zmiennej source_image
        full_file_name="image.png"
        source_image = cv2.imread(full_file_name)
        # konwersja obrazu kolorowego do obrazu w skali szarości
        gray_image = cv2.cvtColor(source_image, cv2.COLOR_BGR2GRAY)
        # skalowanie obrazu za pomocą funkcji resize_image(zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(gray_image, 250, 250)
        window['-IMAGE-'].update(data=source_image_resized_to_show)

    if event == "-AVG3x3-":
        filteredImage=cv2.blur(gray_image, (3, 3))
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(filteredImage, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)

    if event == "-AVG5x5-":
        filteredImage=cv2.blur(gray_image, (5, 5))
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(filteredImage, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)

    if event == "-AVG7x7-":
        filteredImage=cv2.blur(gray_image, (7, 7))
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(filteredImage, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)

    if event == "-MED3x3-":
        filteredImage=cv2.medianBlur(gray_image, 3)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(filteredImage, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)

    if event == "-MED5x5-":
        filteredImage=cv2.medianBlur(gray_image, 5)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(filteredImage, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)

    if event == "-MED7x7-":
        filteredImage=cv2.medianBlur(gray_image, 7)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(filteredImage, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)

    if event == "-SOBEL1-":
        # Wyznaczenie krawędzie poziomych na obrazie
        sobelHorizontal = cv2.Sobel(gray_image, cv2.CV_64F, 0, 1)
        # Konwersja do obrazu w zakresie 0 - 255 (unit8)
        sobelHorizontal = np.uint8(np.absolute(sobelHorizontal))
        image_resized_to_show=resize_image(sobelHorizontal, 250, 250)
        window['-IMAGEDIST-'].update(data=image_resized_to_show)

    if event == "-SOBEL2-":
        # Wyznaczenie krawędzie pionowych na obrazie
        sobelVertical = cv2.Sobel(gray_image, cv2.CV_64F, 1, 0)
        # Konwersja do obrazu w zakresie 0 - 255 (unit8)
        sobelVertical = np.uint8(np.absolute(sobelVertical))
        image_resized_to_show=resize_image(sobelVertical, 250, 250)
        window['-IMAGEDIST-'].update(data=image_resized_to_show)

    if event == "-SOBEL3-":
        # Wyznaczenie krawędzie poziomych i pionowych na obrazie
        sobelHorizontal = cv2.Sobel(gray_image, cv2.CV_64F, 0, 1)
        sobelVertical = cv2.Sobel(gray_image, cv2.CV_64F, 1, 0)
        # Konwersja obrazów z liniami poziomymi i pionowymi do obrazów w zakresie 0 - 255 (unit8)
        sobelHorizontal = np.uint8(np.absolute(sobelHorizontal))
        sobelVertical = np.uint8(np.absolute(sobelVertical))
        # Połączenie wyników detekcji krawędzie poziomych i pionowych na jednym obrazie
        sobelHorizVertic = cv2.bitwise_or(sobelHorizontal, sobelVertical)
        image_resized_to_show=resize_image(sobelHorizVertic, 250, 250)
        window['-IMAGEDIST-'].update(data=image_resized_to_show)

    if event == "-CANNY-":
        # Wyznaczenie krawędzi metodą Canny
        canny_image = cv2.Canny(gray_image, 30, 150)
        # Konwersja do obrazu w zakresie 0 - 255 (unit8)
        canny_image = np.uint8(np.absolute(canny_image))
        image_resized_to_show=resize_image(canny_image, 250, 250)
        window['-IMAGEDIST-'].update(data=image_resized_to_show)

window.close()
        


        





























        
        

            



























