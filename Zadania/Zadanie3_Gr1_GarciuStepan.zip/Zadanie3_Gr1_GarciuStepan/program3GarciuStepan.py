import PySimpleGUI as sg
import os.path
import PIL.Image
import numpy as np
import io
import cv2
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import colors
from matplotlib.ticker import PercentFormatter

"""
Definicja wymaganych funkcji
"""
def resize_image(image, height, width):
    # Funkcja do skalowania obrazu
    newSize = (height, width)
    # zmiana rozmiarów obrazu z pomocą opencv
    source_image_resized = cv2.resize(image, newSize, interpolation = cv2.INTER_AREA)
    # konwersja obrazu do formatu .png
    source_image_resized = cv2.imencode(".png", source_image_resized)[1].tobytes()

    return source_image_resized

left_column = [
    [sg.Text("Garciu Stepan"), sg.Button('Obraz', key="-OBRAZ-")],
    [sg.Image(key="-IMAGE-")]
]


center_column = [
    [sg.Text("Operacje") ],
    [sg.Text("Ściemnianie/Rozjaśnianie")],
    [sg.Slider(key = '-INTENSITY-', range=(-100, 100), #zakres
     orientation='h', enable_events=True, # orientacja i generowanie zdarzeń
     size=(10, 15), default_value = 0)], # wartość domyślna
    [sg.Text("Progowanie z dolnym progiem")],
    [sg.Slider(key = '-THRESHOLD_DOWN-', range=(0, 255), #zakres progu
     orientation = 'h', enable_events=True, # orientacja i generowanie zdarzeń
     size=(10, 15), default_value = 0)], # wartość domyślna
    [sg.Text("Progowanie z górnym progiem")],
    [sg.Slider(key = '-THRESHOLD_UP-', range=(0, 255), #zakres progu
     orientation = 'h', enable_events=True, # orientacja i generowanie zdarzeń
     size=(10, 15), default_value=255)], #wartość domyślna
    [sg.Button('Progowanie OTSU', key="-OTSU-")],
    [sg.Button('Histogram', key="-HIST-")]
]


right_column = [
    [sg.Text("Obraz wynikowy")],
    [sg.Image(key="-IMAGEDIST-")]    
]


layout = [
    [
        sg.Column(left_column),
        sg.VSeparator(),
        sg.Column(center_column),
        sg.VSeparator(),
        sg.Column(right_column)
    ]
]

# Utworzenie okna z przygotowanym rozkładem trzykolumnowym
window = sg.Window("Program3GarciuStepan", layout, resizable=True,
                   size=(800,600), finalize=True)

source_image = None # Zmienna reprezentująca obraz do analizy
# Utworzenie pętli zdarzeń okna aplikacji
while True:
    event, values = window.read()
    # Zakończenie działania aplikacji i zamknięcie okna
    # gdy wyjście z aplikacji
    if event == sg.WIN_CLOSED:
        break
    
    if event == "-OBRAZ-":
        # Wczytanie pliku za pomocą opencv i zapisanie w zmiennej source_image
        full_file_name = "image.png"
        source_image = cv2.imread(full_file_name)
        # skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show=resize_image(source_image, 250, 250)
        window['-IMAGE-'].update(data=source_image_resized_to_show)
        
    if event == "-INTENSITY-":
        val = values["-INTENSITY-"] # odczyt wartości suwaka
        dist_image = source_image + val # zmniejszenie lub zwiększenie jasności obrazu
        dist_image_resized_to_show = resize_image(dist_image, 250, 250)
        window['-IMAGEDIST-'].update(data=dist_image_resized_to_show)
        
    if event == "-THRESHOLD_DOWN-":
        val = values["-THRESHOLD_DOWN-"] # odczyt wartości suwaka
        gray_image = cv2.cvtColor(source_image, cv2.COLOR_BGR2GRAY)
        ret, thresh1_image = cv2.threshold(gray_image, val, 255, cv2.THRESH_BINARY)
        result_image_resized_to_show = resize_image(thresh1_image, 250, 250)
        window['-IMAGEDIST-'].update(data=result_image_resized_to_show)
        
    if event == "-THRESHOLD_UP-":
        val = values["-THRESHOLD_UP-"] # odzcyt wartości suwaka
        gray_image = cv2.cvtColor(source_image, cv2.COLOR_BGR2GRAY)
        ret, thresh2_image = cv2.threshold(gray_image, val, 255, cv2.THRESH_BINARY_INV)
        result_image_resized_to_show=resize_image(thresh2_image, 250, 250)
        window['-IMAGEDIST-'].update(data=result_image_resized_to_show)

    if event == "-OTSU-":
        gray_image = cv2.cvtColor(source_image, cv2.COLOR_BGR2GRAY)
        ret2, thresh3_image = cv2.threshold(gray_image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        result_image_resized_to_show=resize_image(thresh3_image, 250, 250)
        window['-IMAGEDIST-'].update(data=result_image_resized_to_show)

    if event == "-HIST-":
        gray_image = cv2.cvtColor(source_image, cv2.COLOR_BGR2GRAY)
        result_image_resized_to_show = resize_image(gray_image, 250, 250)
        window['-IMAGEDIST-'].update(data=result_image_resized_to_show)
        # Użycie biblioteki matplotlib
        plt.figure("Histogram")
        plt.hist(gray_image)
        plt.show()       
    
        
window.close()




















        
