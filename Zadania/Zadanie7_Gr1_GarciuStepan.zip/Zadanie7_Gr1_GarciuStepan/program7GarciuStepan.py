import PySimpleGUI as sg
import PIL.Image
import numpy as np
import io
import cv2
import numpy as np
import random

"""
Definicja wymaganych funkcji
"""
def resize_image(image, height, width):
    # Funkcja do skalowania obrazu
    newSize = (height, width)
    # zmiana rozmiarów obrazu z pomocą opencv
    source_image_resized = cv2.resize(image, newSize, interpolation = cv2.INTER_AREA)
    # konwersja obrazu do formatu .png
    source_image_resized = cv2.imencode(".png", source_image_resized)[1].tobytes()
    return source_image_resized

def image_generator(row, col, thres):
    #Utworzenie macierzy obrazu kolorowego BGR
    image_bgr = np.zeros((250, 250, 3), dtype = "uint8")
    # Generowanie zakłóceń w postaci szumu
    for i in range(image_bgr.shape[0]):
        for j in range(image_bgr.shape[1]):
            rdn = random.random()
            if rdn > thres:
                image_bgr[i][j] = 255
    # Generowanie elementów graficznych (kwadratów) o losowych kolorach
    count_factor = 25
    for i in range(int(image_bgr.shape[0]/count_factor)):
        for j in range(int(image_bgr.shape[1]/count_factor)):
            rdn = random.random()
            start_point = (count_factor*i-3, count_factor*j-3)
            end_point = (count_factor*i + 3, count_factor*j+3)
            if rdn < 0.33:
                color_blue = (255, 0, 0)
                # Rysowanie wypełnionego prostokąta (kwadratu)
                cv2.rectangle(image_bgr, start_point, end_point, color_blue, -1)
            if rdn > 0.33 and rdn < 0.66:
                color_green = (0, 255, 0)
                cv2.rectangle(image_bgr, start_point, end_point, color_green, -1)
            if rdn > 0.66 and rdn < 1:
                color_red = (0, 0, 255)
                cv2.rectangle(image_bgr, start_point, end_point, color_red, -1)
    return image_bgr


left_column = [
    [sg.Text("Garciu Stepan")],
    [sg.Text("Generuj sztuczny obraz")],
    [sg.Button("Generuj obraz 1", key="-CREATEIMG1-")],
    [sg.Text("Generuj sztuczny obraz")],
    [sg.Button("Generuj obraz 2", key="-CREATEIMG2-")],
    [sg.Text("Generuj sztuczny obraz")],
    [sg.Button("Generuj obraz 3", key="-CREATEIMG3-")],
    [sg.Image(key="-IMAGE-")]
]
center_column = [
    [sg.Text("Analiza")],
    [sg.Button("Analiza obrazu", key="-ANALYSE-")],
    [sg.Text("Wyniki analizy")],
    [sg.Text("Liczba niebieskich")],
    [sg.Text("...", key="-BLUECOUNT-")],
    [sg.Text("Liczba zielonych")],
    [sg.Text("...", key="-GREENCOUNT-")],
    [sg.Text("Liczba czerwonych")],
    [sg.Text("...", key="-REDCOUNT-")],
]
right_column = [
    [sg.Text("Obrazy wynikowe składowe B G R")],
    [sg.Image(key="-IMAGEDISTB-"), sg.Image(key="-IMAGEDISTG-"), sg.Image(key="-IMAGEDISTR-")],
    [sg.Text("Obraz wynikowy")],
    [sg.Image(key="-IMAGEDIST-")]
]
layout = [
    [
        sg.Column(left_column),
        sg.VSeparator(),
        sg.Column(center_column),
        sg.VSeparator(),
        sg.Column(right_column)
    ]
]

# Utworzenie okna z przygotowanym rozkładem trzykolumnowym
window = sg.Window("Program7GarciuStepan", layout, resizable=True,
                   size=(1300, 600), finalize=True)

source_image = None # Zmienna reprezentująca obraz do analizy

# Utworzenie pętli zdarzeń okna aplikacji
while True:
    event, values = window.read()
    # Zakończenie działania aplikacji i zamknięcie okna
    # gdy wyjście z aplikacji
    if event == sg.WIN_CLOSED:
        break
    if event == "-CREATEIMG1-":
        # GEnerowanie sztucznego obrazu o zadanych parametrach - mały szum
        source_image = image_generator(255, 250, 0.95)
        # Skalowanie obrazu za pomocą funkcji resize_image (zdefiniowanej na początku pliku)
        source_image_resized_to_show = resize_image(source_image, 250, 250)
        window['-IMAGE-'].update(data=source_image_resized_to_show)
    if event == "-CREATEIMG2-":
        # Generowanie sztucznego obrazu o zadanych parametrach
        source_image = image_generator(255, 250, 0.75)
        # Skalowanie obrazu za pomocą funkcji resize_image ( zdefiniowanej na początku pliku)
        source_image_resized_to_show = resize_image(source_image, 250, 250)
        window['-IMAGE-'].update(data=source_image_resized_to_show)
    if event == "-CREATEIMG3-":
        # Generowanie sztucznego obrazu o zadanych parametrach
        source_image = image_generator(255, 250, 0.60)
        # Skalowanie obrazu za pomocą funkcji resize_image ( zdefiniowanej na początku pliku)
        source_image_resized_to_show = resize_image(source_image, 250, 250)
        window['-IMAGE-'].update(data=source_image_resized_to_show)
    if event == "-ANALYSE-":
        # Wyszukiwanie 3-ch konkretnych kolorów - podział obrazu na 3 składowe
        image_blue = source_image[:, :, 0]
        image_green = source_image[:, :, 1]
        image_red = source_image[:, :, 2]
        # Prezentacja obrazów dla każdej składowej koloru
        # Na każdym obrazie widać tylko kwadraty określonego koloru
        source_image_resized_to_show = resize_image(image_blue, 250, 250)
        window['-IMAGEDISTB-'].update(data=source_image_resized_to_show)
        source_image_resized_to_show=resize_image(image_green, 250, 250)
        window['-IMAGEDISTG-'].update(data=source_image_resized_to_show)
        source_image_resized_to_show=resize_image(image_red, 250, 250)
        window['-IMAGEDISTR-'].update(data=source_image_resized_to_show)
        # Usuwanie szumu z obrazów składowych za pomocą operacji Otwarcia
        # Przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 3x3
        se3x3 = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
        # Operacja otwarcia elementem strukturalnym SE dla składowej BLUE
        opened_image_blue = cv2.morphologyEx(image_blue, cv2.MORPH_OPEN, se3x3)
        # Operacja otwarcia elementem strukturalnym SE dla składowej GREEN
        opened_image_green = cv2.morphologyEx(image_green, cv2.MORPH_OPEN, se3x3)
        # Operacja otwarcia elementem strukturalnym SE dla składowej RED
        opened_image_red = cv2.morphologyEx(image_red, cv2.MORPH_OPEN, se3x3)
        # Wyznaczenie liczby kwadratów B, G, R na obrazach składowych B, G, R
        contoursB, hB = cv2.findContours(opened_image_blue, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        contoursG, hG = cv2.findContours(opened_image_green, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        contoursR, hR = cv2.findContours(opened_image_red, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        # Złączenie obrazów B, G, R do jednego obrazu kolorowego
        image_result_bgr = cv2.merge((opened_image_blue, opened_image_green, opened_image_red))
        # Prezentacja wyników analizy (liczba kwadratów każdego koloru)
        window.Element('-BLUECOUNT-').update(str(len(contoursB)))
        window.Element('-GREENCOUNT-').update(str(len(contoursG)))
        window.Element('-REDCOUNT-').update(str(len(contoursR)))

        source_image_resized_to_show = resize_image(image_result_bgr, 250, 250)
        window['-IMAGEDIST-'].update(data=source_image_resized_to_show)

        
        
        
    
    
    























                
