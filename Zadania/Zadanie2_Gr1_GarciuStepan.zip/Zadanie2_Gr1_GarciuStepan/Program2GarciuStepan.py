# program2GarciuStepan.py

import PySimpleGUI as sg
import os.path
import PIL.Image
import numpy as np
import io
import cv2

"""
Definicja wymaganych funkcji
"""
def convert_and_resize(file_or_bytes, resize=None):
    # Funkcja skalowania obrazu
    # Odczyt pliku obrazu
    img = PIL.Image.open(file_or_bytes)
    # Szerokość i wysokość wczytanego obrazu
    cur_width, cur_height = img.size
    
    if resize: # Jeżeli podano rozmiar obrazu - obraz zostanie przeskalowany
        # Docelowy rozmiar obrazu
        new_width, new_height = resize
        # Wyznaczenie docelowej skali obrazu na podstawie zadanego rozmiaru
        scale = min(new_height/cur_height, new_width/cur_width)
        # Wykonanie skalowania obrazu do rozmiaru docelowego
        img = img.resize((int(cur_width*scale), int(cur_height*scale)), PIL.Image.ANTIALIAS)
        
    bio = io.BytesIO() # Przygotowanie strumienia danych
    img.save(bio, format="PNG") #Zapisanie obrazu w nowym rozmiarze do strumienia danych w PNG
    del img # Usunięcie obrazu wykorzystanego w procesie skalowania
    
    return bio.getvalue() # Funkcja zwraca strumień danych zawierający skalowany obraz w PNG

    
file_list_column = [
    [   sg.Text("Garciu Stepan")
    ],
    [
        sg.Text("Folder obrazów"),
        sg.In(size=(25, 1), enable_events=True, key="-FOLDER-"),
        sg.FolderBrowse(button_text='Wybierz', target='-FOLDER-', initial_folder=os.getcwd()),        
    ],
    [
        sg.Listbox(
            values=[], enable_events=True, size=(40, 20), key="-FILE LIST-"
        )
    ],
]

image_viewer_column = [
    [sg.Text("Wybierz obraz z listy:")],
    [sg.Text(size=(40, 1), key="-TOUT-")],
    [sg.Image(key="-IMAGE-")],
    [sg.Text("Konwersja kolorów"), sg.Button('Wykonaj', key="-CONV-")],
    [sg.Text("Translacja"), sg.In(size=(5, 1), default_text="0", key="-TRANS_VAL-"), sg.Button('Wykonaj', key="-TRANS-")],
    [sg.Text("Rotacja"), sg.In(size=(5, 1), default_text="0", key="-ROT_VAL-"), sg.Button("Wykonaj", key="-ROT-")],
    [sg.Text("Skalowanie"), sg.In(size=(5, 1), default_text="0", key="-SCAL_VAL-"), sg.Button('Wykonaj', key="-SCAL-")],
]

layout = [
    [
        sg.Column(file_list_column),
        sg.VSeparator(),
        sg.Column(image_viewer_column),
    ]
]

# Utworzenie okna z przygotowanym rozkładem dwukolumnowym
window = sg.Window("Program2GarciuStepan", layout, resizable=True,
                   size=(800, 600), finalize=True)

source_image = None # Zmienna reprezentująca obraz do analizy
# Utworzenie pętli zdarzeń okna aplikacji
while True:
    event, values = window.read()
    # Zakończenie działania aplikacji i zamknięcie okna
    # gdy wyjście z aplikacji
    
    if event == "Exit" or event == sg.WIN_CLOSED:
        break
    
    if values['-FOLDER-'] != '': # jeżeli wartość komponentu -FOLDER- niepusta
        # odczytaj listę plików ze wskazanego folderu
        file_list = os.listdir(values['-FOLDER-'])
        # uaktualnij listę o pliki znajdujące się w wybranym folderze np. Obrazy
        window['-FILE LIST-'].update(file_list) # uaktualnij listę plików
        
    if event == '-FILE LIST-':
        file_path=values['-FOLDER-'] #odczyt wartości z komponentu -FOLDER-
        selected_file=values['-FILE LIST-'] #odczyt wartości z listy plików
        full_file_name=os.path.join(file_path, selected_file[0]) #odczyt pozycji
        #aktualizacja komponentu -IMAGE- i wczytanie wybranego pliku
        #window['-IMAGE-'].update(full_file_name)
        new_size = 300, 300
        window['-IMAGE-'].update(data=convert_and_resize(full_file_name, resize=new_size))
        # Wczytanie pliku za pomocą opencv i zapisanie w zmiennej source_image
        source_image = cv2.imread(full_file_name)
        sg.Popup('Wczytano plik', selected_file[0])
        
    # Obsługa operacji na obrazie
    # Konwersja obrazu do skali szarości
    if event == '-CONV-': # Reakcja na przycisk Konwersja
        image_gray = cv2.cvtColor(source_image, cv2.COLOR_BGR2GRAY)
        cv2.imshow('Konwersja', image_gray)
        
    if event == '-TRANS-': # Reakcja na przycisk Translacja
        height, width = source_image.shape[:2]
        trans=values["-TRANS_VAL-"] # Odczyt wartości translacji z pola edycyjnego -TRANS-VAL-
        # Macierz tranclacji - taka sama wartości dla osi X i Y
        mat = np.float32([[1, 0, trans], [0, 1, trans]])
        # Wykonanie translacji i obcięcie obrazu wyjściowego
        image_trans = cv2.warpAffine(source_image, mat, (width, height))
        cv2.imshow('Konwersja', image_trans)
        
    if event == '-ROT-': # Reakcja na przycisk Rotacja
        height, width = source_image.shape[:2]
        rotate=values["-ROT_VAL-"] # Odczyt wartości translacji z pola edycyjnego -ROT-VAL-
        center = (width // 2, height // 2) # Współrzędne środka obrazu
        # Macierz rotacji
        mat = cv2.getRotationMatrix2D(center, np.float32(rotate), 1.0)
        # Wykonanie rotacji i obcięcie obrazu wyjściowego
        image_rot = cv2.warpAffine(source_image, mat, (width, height))
        cv2.imshow('Rotacja', image_rot)
        
    if event == '-SCAL-': # Reakcja na przycisk Skalowanie
        height, width = source_image.shape[:2]
        scal=values["-SCAL_VAL-"] # Odczyt wartości skalowanie z pola edycyjnego -SCAL-VAL-
        # Macierz skalowania - taka sama wartości dla osi X i Y
        mat = np.float32([[scal, 0, 0], [0, scal, 0]])
        # Wykonanie skalowania i obcięcie obrazu wyjściowego
        image_scal = cv2.warpAffine(source_image, mat, (width, height))
        cv2.imshow('Skalowanie', image_scal)
        
window.close()


    
