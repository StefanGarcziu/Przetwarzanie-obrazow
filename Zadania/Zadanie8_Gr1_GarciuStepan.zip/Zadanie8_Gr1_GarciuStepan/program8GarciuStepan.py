import PySimpleGUI as sg
import PIL.Image
import numpy as np
import cv2
import copy
from matplotlib import pyplot as plt

"""
Definicja wymaganych funkcji
"""
def resize_image(image, height, width):
    # Funkcja do skalowania obrazu
    newSize = (height, width)
    # zmiana rozmiarów obrazu z pomocą opencv
    source_image_resized = cv2.resize(image, newSize, interpolation = cv2.INTER_AREA)
    # konwersja obrazu do formatu .png
    source_image_resized = cv2.imencode(".png", source_image_resized)[1].tobytes()
    return source_image_resized


left_column = [
    [sg.Text("Garciu Stepan")],
    [sg.Text("Obraz do analizy")],    
    [sg.Image(key="-IMAGE-")]
]
center_column = [
    [sg.Text("Analiza")],
    [sg.Button("Analiza obrazu", key="-ANALYSE-")],
    [sg.Text("Wyniki analizy")],
    [sg.Text("Liczba komórek")],
    [sg.Text("...", key="-CELLSCOUNT-")],
    [sg.Text("Liczba komórek ZDROWYCH")],
    [sg.Text("...", key="-GREENCOUNT-")],
    [sg.Text("Liczba komórek CHORYCH")],
    [sg.Text("...", key="-REDCOUNT-")],
]
right_column = [
    [sg.Text("Obrazy wynikowe kolejne etapy analizy")],
    [sg.Text("Podział na składowe zielona i czerwona")],
    [sg.Image(key="-IMAGEDIST1-"), sg.Image(key="-IMAGEDIST2-")],
    [sg.Text("Efekt morfologicznego otwarcia obrazów")],
    [sg.Image(key="-IMAGEDIST3-"), sg.Image(key="-IMAGEDIST4-")],
    [sg.Text("Obraz wynikowy")],
    [sg.Image(key="-IMAGEDIST-")]
]

layout = [
    [
        sg.Column(left_column),
        sg.VSeparator(),
        sg.Column(center_column),
        sg.VSeparator(),
        sg.Column(right_column)
    ]
]

# Utworzenie okna z przygotowanym rozkładem trzykolumnowym

window = sg.Window("Program8GarciuStepan", layout, resizable=True,
                   size=(1200, 800), finalize=True)

source_image = None # Zmienna reprezentująca obraz do analizy
source_image = cv2.imread('imageCells.png')

source_image_resized_to_show=resize_image(source_image, 411, 280)
window['-IMAGE-'].update(data=source_image_resized_to_show)

# Utworzenie pętli zdarzeń okna aplikacji
while True:
    event, values = window.read()
    # Zakończenie działania aplikacji i zamknięcie okna
    # gdy wyjście z aplikacji
    if event == sg.WIN_CLOSED:
        break

    if event == "-ANALYSE-":
        # Wyszukiwanie 2-ch konkretnych kolorów - podział obrazu na 2 składowe
        # Kolory istotne na przykładowym obrazie to czerwony i zielony
        image_green = source_image[:,:,1]
        image_red = source_image[:,:,2]
        #Prezentacja obrazów dla każdej składowej koloru (komórki i czerwone plamy)
        # Na każdym obrazie widać tylko wybrane fragmenty komórek        
        source_image_resized_to_show = resize_image(image_green, 206, 140)
        window['-IMAGEDIST1-'].update(data=source_image_resized_to_show)
        source_image_resized_to_show = resize_image(image_green, 206, 140)
        window['-IMAGEDIST2-'].update(data=source_image_resized_to_show)

        # progowanie obrazów (binaryzacja składowej czerwonej i zielonej)
        # w celu segmentacji konkretnych fragmentów komórek
        ret1, image_green_binarized = cv2.threshold(image_green, 30, 255, cv2.THRESH_BINARY)
        ret2, image_red_binarized = cv2.threshold(image_red, 127, 255, cv2.THRESH_BINARY)
        # Usuwanie drobnych pozostałości po binaryzacji obrazu składowej czerwonej i zielonej
        # Przygotowanie elementu strukturalnego (kwadratowego) o rozmiarze 5x5
        se5x5 = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
        # Operacja otwarcia elementem strukturalnym SE dla składowej RED i GREEN
        image_green_binarized_opened = cv2.morphologyEx(image_green_binarized, cv2.MORPH_OPEN, se5x5)
        image_red_binarized_opened = cv2.morphologyEx(image_red_binarized, cv2.MORPH_OPEN, se5x5)

        # Prezentacja obrazów po przetwarzaniu i segmentacji
        image_green_binarized_to_show = resize_image(image_green_binarized_opened, 206, 140)
        image_red_binarized_opened_to_show = resize_image(image_red_binarized_opened, 206, 140)
        window['-IMAGEDIST3-'].update(data=image_green_binarized_to_show)
        window['-IMAGEDIST4-'].update(data=image_red_binarized_opened_to_show)

        # Wyznaczenie listy konturów komórek na obrazie binarnym ze składowej zielonej
        contoursGreen, hG = cv2.findContours(image_green_binarized_opened, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        # Wyznaczenie listy konturów czerwonych plam na obrazie binarnym ze składowej czerwonej po otwarciu
        contoursRed, hG = cv2.findContours(image_red_binarized_opened, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

        # Deklaracja listy z danymi o obszarach czerwonych zakłóceń
        redDotList = []
        # Wyznaczenie centroidów wszystkich czerwonych zakłóceń wewnątrz komórek
        # z wykorzystaniem metody momentów
        for cntRed in contoursRed:
            MRed = cv2.moments(cntRed)
            # print (MRed)
            # Wyznaczenie centroidu czerwonego zakłócenia
            cx = int(MRed['m10']/MRed['m00'])
            cy = int(MRed['m01']/MRed['m00'])
            redDotList.append((cx, cy))

        # Deklaracja listy z danymi o obszarach komórek (czyli zielonych)
        cellsInfoList = []
        # Sprawdzenie które kontury komórek zawierają wewnątrz czerwone zakłócenie
        # Komórka z czerwonym elementem - Chora, komórka bez czerwonego zakłócenia - Zdrowa
        cellIdx = 1; # Licznik indeksów komórek (każda znaleziona komórka ma swój indeks)
        for cntGreen in contoursGreen:
            MGreen = cv2.moments(cntGreen)
            # Wyznaczenie centroidu komórki
            cell_cx = int(MGreen['m10']/MGreen['m00'])
            cell_cy = int(MGreen['m01']/MGreen['m00'])
            cellStatus = 'Zdrowa'
            # Sprawdzenie czy kontur zawiera chociaż 1 czerwony element
            # jeżeli znajdzie chociaż jeden przerywa dalsze wyszukiwanie
            # i sprawdza kolejną komórkę
            for redPoint in redDotList:
                cx = redPoint[0]
                cy = redPoint[1]
                # print ( redPoint )
                # Sprawdzenie czy czerwone zakłócenie z listy znajduje się wewnątrz
                # aktualnie sprawdzanej komórki
                dist = cv2.pointPolygonTest(cntGreen, (cx, cy), True)
                if dist >= 0:
                    cellStatus = 'Chora' # Komórka zawiera czerwoną plamkę -> zmiana statusu - Chora
                    break
            # Dodanie informacji o komórce do listy (indeksy komórki, współrzędne centroidu, status komórki)
            cellsInfoList.append(tuple((cellIdx, cell_cx, cell_cy, cellStatus)))
            cellIdx = cellIdx + 1

        # Głęboka kopia obrazu badanego funkcja copy.deepcopy(...)
        source_image_analysed = copy.deepcopy(source_image)
        countGreen = 0; # Licznik komórek zdrowych - zielonych
        countRed = 0; # Licznik komórek chorych - czerwonych
        for cellInfo in cellsInfoList:
            cellIdx = cellInfo[0]
            cx = cellInfo[1]
            cy = cellInfo[2]
            status = cellInfo[3]
            # print (cellInfo)

            font = cv2.FONT_HERSHEY_SIMPLEX

            if status == 'Zdrowa':
                # Oznaczenie zielony prostokąt
                cv2.rectangle(source_image_analysed, (cx-20, cy-20), (cx+20, cy+20), (0, 255,0), 2)
                cv2.putText(source_image_analysed, str(cellIdx), (cx, cy), font, 1, (255, 255, 255), 2)
                countGreen = countGreen + 1
            if status == 'Chora':
                # Oznaczenie czerwony prostokąt
                cv2.rectangle(source_image_analysed, (cx-20, cy-20), (cx+20, cy+20), (0, 0, 255), 2)
                cv2.putText(source_image_analysed, str(cellIdx), (cx, cy), font, 1, (255, 255, 255), 2)
                countRed = countRed + 1
        source_image_analysed_to_show = resize_image(source_image_analysed, 411, 280)
        window['-IMAGEDIST-'].update(data=source_image_analysed_to_show)

        # Wyznaczenie i prezentacja danych liczbowych
        # Liczba wszystkich komórek
        window.Element('-CELLSCOUNT-').update(str(len(cellsInfoList)))
        window.Element('-GREENCOUNT-').update(str(countGreen))
        window.Element('-REDCOUNT-').update(str(countRed))

        # Dodatkowa prezentacja za pomocą matplotlib
        plt.figure('Obraz wynikowy po analizie', figsize=(10, 8))
        # Wyświetlenie obrazu z konwersją formatu z OpenCV (BGR) do (RGB)
        plt.subplot(111), plt.imshow(cv2.cvtColor(source_image_analysed, cv2.COLOR_BGR2RGB))
        plt.title('Obraz wynikowy po analizie'), plt.xticks([]), plt.yticks([])
        plt.show()

        
        
            
        
        

        
   






































