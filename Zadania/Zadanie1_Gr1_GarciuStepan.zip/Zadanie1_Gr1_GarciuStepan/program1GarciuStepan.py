# program1GarciuStepan.py

import PySimpleGUI as sg

layout = [[sg.Text("Garciu Stepan")],
          [sg.Button("OK")],
          [sg.Image(key="-IMAGE-")],]

# Utworzenie okna
window = sg.Window("Program1", layout, resizable=True,
                   size=(800, 600), finalize=True)

window["-IMAGE-"].update("image.png")

# Utworzenie pętli zdarzeń okna aplikacji
while True:
    event, values = window.read()
    # Zakończenie dzałania aplikacji gdy użytkownik naciśnie
    # przycisk OK w oknie aplikacji
    if event == "OK" or event == sg.WIN_CLOSED:
        break

window.close()
